﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace ХРАНИТЕЛЬ_ПРО
{
    /// <summary>
    /// Логика взаимодействия для SinglePos.xaml
    /// </summary>
    public partial class SinglePos : Window
    {
        public SinglePos()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DateTime fd = Convert.ToDateTime(dat1.Text);
            DateTime td = Convert.ToDateTime(dat2.Text);
            string trarg = Цель.Text;
            int Kodprimsotr = Convert.ToInt32(Номер_сотрудника.Text);
            string fam = LastName.Text;
            string nam = Namee.Text;
            string otc = Otchestvo.Text;
            string phon = tel.Text;
            string mail = email.Text;
            string ser = paspseria.Text;
            string nom = paspnomer.Text;
            DateTime birt = Convert.ToDateTime(datebirth.Text);         
            int код = Convert.ToInt32(zayavka.Text);

            using (var bd = new Хранитель_ПРО_КротоваEntities())
            {
                var propusk = new Пропуск();             
                var posetitel = new Пользователи();
                var Zayavka = new Заявка_на_посещение();

                propusk.Код_заявки = код;          
                propusk.Цель_посещения = trarg;
                propusk.Принимающий_сотрудник = Kodprimsotr;
                bd.Пропуск.Add(propusk);
                bd.SaveChanges();

                posetitel.Фамилия = fam;
                posetitel.Имя = nam;
                posetitel.Отчество = otc;
                posetitel.Дата_рождения = birt;
                posetitel.Номер_телефона = phon;
                posetitel.Серия_паспорта = ser;
                posetitel.Номер_паспорта = nom;
                posetitel.Email = mail;                                       
                bd.Пользователи.Add(posetitel);
                bd.SaveChanges();

                

                Zayavka.Код_заявки= код;
                Zayavka.Начало_срока_действия= fd;
                Zayavka.Конец_срока_действия = td;
                bd.Заявка_на_посещение.Add(Zayavka);
                bd.SaveChanges();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            dat1.Clear();
            dat2.Clear();
            Цель.Clear();
            LastName.Clear();
            Номер_сотрудника.Clear();
            Namee.Clear();
            Otchestvo.Clear();
            tel.Clear();
            email.Clear();
            datebirth.Clear();
            paspseria.Clear();
            paspnomer.Clear();
            zayavka.Clear();
          
        }
    }
}
